This file is a copy of the HTML diff script found here:
https://dev.w3.org/cvsweb/2009/htmldiff/
