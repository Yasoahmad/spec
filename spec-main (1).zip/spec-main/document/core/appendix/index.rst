.. _appendix:

Appendix
========

.. toctree::
   :maxdepth: 2

   embedding
   implementation
   algorithm
   custom
   properties
   changes

.. only:: singlehtml

   .. toctree::

      index-types
      index-instructions
      index-rules

