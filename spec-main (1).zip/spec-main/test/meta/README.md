These programs generate test cases.  See Makefile for details.
